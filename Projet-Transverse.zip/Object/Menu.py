class Menu :

  # Class for Menus

  class Display :

    # Class for Displaying the Menus
    
    def main(self) :

      pass