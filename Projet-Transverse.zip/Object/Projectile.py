class Projectile :

  # 

  def __init__() :

    #
    
    pass