 class Terrain :

  # 

  def __init__() :

    #
    
    pass