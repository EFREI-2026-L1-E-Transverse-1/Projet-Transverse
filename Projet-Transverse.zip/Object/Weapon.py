class Weapon :

  # 

  def __init__() :

    #
    
    pass