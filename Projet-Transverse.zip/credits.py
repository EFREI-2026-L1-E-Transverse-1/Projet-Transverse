import pygame
def credits():
    print("Crédits !")
    background = pygame.image.load("assets/credits.jpg")

    return background