# Blobs Battle

### Projet Transverse

## Informations

- **Date d'Échéance** : 24-25-57 Mai 2022  

### Auteurs

#### Groupe E5
- **Alix Brunet**      _(20211029)_  
- **Martin Kang**      _(20210612)_  
- **Alexandre Manjarres**  _(20210639)_  
- **Léa Varing**        _(20210703)_  
- **Adem Debbahi**             _()_  
  
## Détails

- **Fichier à Exécuter** : main.py  
- **Dépendances** : Pygames, Numpy  

## Description

Notre projet est un jeu de tir de plateforme jouable à deux joueurs.  
Chaque joueur contrôle une équipe de personnages, la partie se déroulant au tour par tour.  
Le joueur choisit un de ses personnage au début de son tour, une arme (différentes armes avec des propriétés uniques sont disponibles), et doit viser pour toucher un ou plusieurs des personnages du joueur adverse.  
Le joueur qui n’a plus de personnages alliés a perdu.  